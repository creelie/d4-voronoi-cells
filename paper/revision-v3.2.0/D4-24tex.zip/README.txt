Compile D4.tex with pdfLaTeX (three passes).
Certificate data and checkers are in the repository at the release tag.
