Compile MDPIv12D424.tex with pdfLaTeX, three passes.
The unrestricted cases of (G) and (C) remain open.
