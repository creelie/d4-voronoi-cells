Compile D4.tex with pdfLaTeX, three passes.
The complete manuscript incorporates a quantitative angular stability theorem for unequal root push-outs, with an explicit packing example. The unrestricted cases (G) and (C) remain open.
The release source tree contains earlier computational and formal-verification materials with their original scope.
