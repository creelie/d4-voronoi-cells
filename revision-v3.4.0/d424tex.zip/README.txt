Compile D4.tex with pdfLaTeX, three passes.

Section 7.10 proves the uniform annular correction. Section 8 applies
it to obtain the density bound below 0.634764. Appendix I derives and
checks the constants. The diagram in Section 7.10 is drawn in TikZ.

The standard-library checkers can be run from this directory.
  python anc/annular_constants.py
  python anc/exterior_test.py
The corresponding results are in the log files under anc/.

The unrestricted cases (G) and (C) remain open. The DOI in the paper
identifies the preceding archival version. The earlier computational
and formal-verification materials retain their stated scope.
