The Sphere Packing Problem in Dimension 4 and the Twenty-Four-Cell Conjecture
Research revision v3.5.1

Compile D4.tex with pdfLaTeX at least three times.
Release: https://github.com/creelie/d4-voronoi-cells/releases/tag/v3.5.1
